# Manga gallery

A Pen created on CodePen.io. Original URL: [https://codepen.io/demonslayertanjiro/pen/vYbBgqy](https://codepen.io/demonslayertanjiro/pen/vYbBgqy).

Cute Manga gallery inspired (copied) from FreeCodeCamps- learn flex box by building a cat gallery challenge;)